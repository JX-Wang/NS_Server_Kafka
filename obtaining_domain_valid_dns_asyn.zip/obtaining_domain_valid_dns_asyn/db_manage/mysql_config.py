# encoding:utf-8
"""
数据库配置文件
"""


# 本地数据库
SOURCE_CONFIG_LOCAL = {
    'host': '10.245.146.39',
    'port': 3306,
    'user': 'root',
    'passwd': 'platform',
    'db': 'domain_valid_dns',
    'charset': 'utf8',
    'use_unicode': True
}
